
#include "odometry.h"
#include "encoder.h"

#include <Arduino.h>
#include <math.h>

// Dimensões do robô
#define WHEEL_DIAMETER 0.065f
#define WHEEL_BASE 0.1775f

// Encoder JGA370:
// 11 PPR por canal no eixo de entrada
// Redução de 45:1
// Contagem de uma borda (RISING) de um canal
#define ENCODER_PULSES_PER_REV 1980.0f

float x = 0.0f;
float y = 0.0f;
float theta = 0.0f;

float linear_velocity = 0.0f;
float angular_velocity = 0.0f;

long previous_left_pulses = 0;
long previous_right_pulses = 0;

unsigned long previous_time = 0;

void odometry_init()
{
    x = 0.0f;
    y = 0.0f;
    theta = 0.0f;

    linear_velocity = 0.0f;
    angular_velocity = 0.0f;

    previous_left_pulses = encoder_get_left();
    previous_right_pulses = encoder_get_right();

    previous_time = millis();
}

void odometry_update()
{
    unsigned long current_time = millis();

    float dt = (current_time - previous_time) / 1000.0f;

    if (dt <= 0.0f) {
        return;
    }

    previous_time = current_time;

    long current_left_pulses = encoder_get_left();
    long current_right_pulses = encoder_get_right();

    long delta_left =
        current_left_pulses - previous_left_pulses;

    long delta_right =
        current_right_pulses - previous_right_pulses;

    previous_left_pulses = current_left_pulses;
    previous_right_pulses = current_right_pulses;

    // Conversão de pulsos para distância percorrida
    float wheel_circumference = PI * WHEEL_DIAMETER;

    float distance_per_pulse =
        wheel_circumference / ENCODER_PULSES_PER_REV;

    float left_distance = delta_left * distance_per_pulse;
    float right_distance = delta_right * distance_per_pulse;

    // Cinemática diferencial
    float distance = (left_distance + right_distance) / 2.0f;

    float delta_theta =
        (right_distance - left_distance) / WHEEL_BASE;

    // Atualização da pose usando o ângulo médio do intervalo
    float theta_middle = theta + delta_theta / 2.0f;

    x += distance * cosf(theta_middle);
    y += distance * sinf(theta_middle);

    theta += delta_theta;

    // Velocidades estimadas
    linear_velocity = distance / dt;
    angular_velocity = delta_theta / dt;
}

float odometry_get_x()
{
    return x;
}

float odometry_get_y()
{
    return y;
}

float odometry_get_theta()
{
    return theta;
}

float odometry_get_linear_velocity()
{
    return linear_velocity;
}

float odometry_get_angular_velocity()
{
    return angular_velocity;
}
