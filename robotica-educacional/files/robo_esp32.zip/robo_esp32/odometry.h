#ifndef ODOMETRY_H
#define ODOMETRY_H

// ========================================
// Inicialização
// ========================================

void odometry_init();

// ========================================
// Atualização da odometria
// ========================================

void odometry_update();

// ========================================
// Pose atual
// ========================================

float odometry_get_x();
float odometry_get_y();
float odometry_get_theta();

// ========================================
// Velocidades
// ========================================

float odometry_get_linear_velocity();
float odometry_get_angular_velocity();

#endif