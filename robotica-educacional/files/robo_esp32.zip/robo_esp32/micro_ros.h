#ifndef MICRO_ROS_H
#define MICRO_ROS_H

// ========================================
// Inicialização do Micro-ROS
// ========================================

void micro_ros_init();

// ========================================
// Processamento do Micro-ROS
// ========================================

void micro_ros_spin();

#endif