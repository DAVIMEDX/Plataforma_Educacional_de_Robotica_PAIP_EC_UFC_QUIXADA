
#ifndef ENCODER_H
#define ENCODER_H

// Encoder do motor esquerdo
#define ENCODER_LEFT_PIN_A 34
#define ENCODER_LEFT_PIN_B 35

// Encoder do motor direito
#define ENCODER_RIGHT_PIN_A 12
#define ENCODER_RIGHT_PIN_B 13

void encoder_init();

long encoder_get_left();
long encoder_get_right();

void encoder_reset();

#endif
