#include "micro_ros.h"

#include <Arduino.h>
#include <WiFi.h>
#include <micro_ros_arduino.h>

#include <rcl/rcl.h>
#include <rclc/rclc.h>
#include <rclc/executor.h>

#include <geometry_msgs/msg/twist.h>
#include <nav_msgs/msg/odometry.h>

#include "motor_control.h"
#include "odometry.h"

// ======================================================
// Wi-Fi
// ======================================================

char WIFI_SSID[] = "Nome da sua rede";
char WIFI_PASSWORD[] = "Sua Senha";

char AGENT_IP[] = "IP encontrado no host";
const uint32_t AGENT_PORT = 8888;


// ======================================================
// ROS 2
// ======================================================

rcl_node_t node;
rclc_support_t support;
rcl_allocator_t allocator;
rclc_executor_t executor;

rcl_subscription_t cmd_vel_subscriber;
rcl_publisher_t odom_publisher;

geometry_msgs__msg__Twist cmd_vel_msg;
nav_msgs__msg__Odometry odom_msg;


// ======================================================
// Controle de segurança
// ======================================================

unsigned long last_cmd_vel_time = 0;

#define CMD_VEL_TIMEOUT_MS 500


// ======================================================
// Callback do /cmd_vel
// ======================================================

void cmd_vel_callback(
    const void *msgin)
{
    const geometry_msgs__msg__Twist *msg =
        (const geometry_msgs__msg__Twist *)msgin;

    float linear_x = msg->linear.x;
    float angular_z = msg->angular.z;

    // --------------------------------------------------
    // Conversão diferencial
    // --------------------------------------------------

    float left = linear_x - angular_z;
    float right = linear_x + angular_z;

    // Normaliza caso ultrapasse 1.0
    float max_value =
        max(abs(left), abs(right));

    if (max_value > 1.0f)
    {
        left /= max_value;
        right /= max_value;
    }

    int left_pwm =
        (int)(left * MOTOR_PWM_MAX);

    int right_pwm =
        (int)(right * MOTOR_PWM_MAX);

    motor_set(left_pwm, right_pwm);

    last_cmd_vel_time = millis();
}


// ======================================================
// Inicialização do Micro-ROS
// ======================================================

void micro_ros_init()
{
    // --------------------------------------------------
    // Serial
    // --------------------------------------------------

    Serial.begin(115200);

    delay(2000);

    Serial.println();
    Serial.println("=================================");
    Serial.println(" Robo ESP32 - Micro-ROS");
    Serial.println("=================================");


    // --------------------------------------------------
    // Wi-Fi
    // --------------------------------------------------

    set_microros_wifi_transports(
        WIFI_SSID,
        WIFI_PASSWORD,
        AGENT_IP,
        AGENT_PORT
    );

    Serial.println("Conectando ao Wi-Fi...");

    while (WiFi.status() != WL_CONNECTED)
    {
        delay(500);
        Serial.print(".");
    }

    Serial.println();
    Serial.println("Wi-Fi conectado!");

    Serial.print("IP do ESP32: ");
    Serial.println(WiFi.localIP());

    Serial.print("Agent: ");
    Serial.println(AGENT_IP);

    Serial.print("Porta: ");
    Serial.println(AGENT_PORT);


    // --------------------------------------------------
    // Micro-ROS
    // --------------------------------------------------

    allocator = rcl_get_default_allocator();

    rclc_support_init(
        &support,
        0,
        NULL,
        &allocator
    );

    rclc_node_init_default(
        &node,
        "robo_esp32",
        "",
        &support
    );


    // --------------------------------------------------
    // Subscriber /cmd_vel
    // --------------------------------------------------

    rclc_subscription_init_default(
        &cmd_vel_subscriber,
        &node,
        ROSIDL_GET_MSG_TYPE_SUPPORT(
            geometry_msgs,
            msg,
            Twist
        ),
        "/cmd_vel"
    );


    // --------------------------------------------------
    // Publisher /odom
    // --------------------------------------------------

    rclc_publisher_init_default(
        &odom_publisher,
        &node,
        ROSIDL_GET_MSG_TYPE_SUPPORT(
            nav_msgs,
            msg,
            Odometry
        ),
        "/odom"
    );


    // --------------------------------------------------
    // Inicialização da mensagem
    // --------------------------------------------------

    cmd_vel_msg.linear.x = 0.0;
    cmd_vel_msg.linear.y = 0.0;
    cmd_vel_msg.linear.z = 0.0;

    cmd_vel_msg.angular.x = 0.0;
    cmd_vel_msg.angular.y = 0.0;
    cmd_vel_msg.angular.z = 0.0;


    // --------------------------------------------------
    // Executor
    // --------------------------------------------------

    rclc_executor_init(
        &executor,
        &support.context,
        1,
        &allocator
    );

    rclc_executor_add_subscription(
        &executor,
        &cmd_vel_subscriber,
        &cmd_vel_msg,
        &cmd_vel_callback,
        ON_NEW_DATA
    );


    last_cmd_vel_time = millis();

    Serial.println("Micro-ROS inicializado.");
    Serial.println("Subscriber: /cmd_vel");
    Serial.println("Publisher: /odom");
}


// ======================================================
// Publicação da odometria
// ======================================================

void publish_odometry()
{
    odom_msg.pose.pose.position.x =
        odometry_get_x();

    odom_msg.pose.pose.position.y =
        odometry_get_y();

    odom_msg.pose.pose.position.z = 0.0;


    float theta =
        odometry_get_theta();


    // --------------------------------------------------
    // Orientação 2D → quaternion
    // --------------------------------------------------

    odom_msg.pose.pose.orientation.x = 0.0;
    odom_msg.pose.pose.orientation.y = 0.0;

    odom_msg.pose.pose.orientation.z =
        sin(theta / 2.0f);

    odom_msg.pose.pose.orientation.w =
        cos(theta / 2.0f);


    // --------------------------------------------------
    // Velocidades
    // --------------------------------------------------

    odom_msg.twist.twist.linear.x =
        odometry_get_linear_velocity();

    odom_msg.twist.twist.angular.z =
        odometry_get_angular_velocity();


    rcl_publish(
        &odom_publisher,
        &odom_msg,
        NULL
    );
}


// ======================================================
// Processamento do Micro-ROS
// ======================================================

void micro_ros_spin()
{
    // Processa mensagens recebidas
    rclc_executor_spin_some(
        &executor,
        RCL_MS_TO_NS(20)
    );


    // --------------------------------------------------
    // Watchdog
    // --------------------------------------------------

    if (millis() - last_cmd_vel_time >
        CMD_VEL_TIMEOUT_MS)
    {
        motor_stop();
    }


    // --------------------------------------------------
    // Atualiza odometria
    // --------------------------------------------------

    odometry_update();


    // --------------------------------------------------
    // Publica odometria
    // --------------------------------------------------

    static unsigned long last_odom_publish = 0;

    if (millis() - last_odom_publish >= 50)
    {
        last_odom_publish = millis();

        publish_odometry();
    }
}
