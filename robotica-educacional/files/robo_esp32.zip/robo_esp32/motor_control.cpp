#include "motor_control.h"
#include "Arduino.h"

// ======================================================
// Configuração dos motores
// ======================================================

void motor_init()
{
    // Configurar os quatro pinos dos motores
    pinMode(MOTOR_LEFT_IN1, OUTPUT);
    pinMode(MOTOR_LEFT_IN2, OUTPUT);
    pinMode(MOTOR_RIGHT_IN1, OUTPUT);
    pinMode(MOTOR_RIGHT_IN2, OUTPUT);

    // Garantir estado inicial desligado
    digitalWrite(MOTOR_LEFT_IN1, LOW);
    digitalWrite(MOTOR_LEFT_IN2, LOW);
    digitalWrite(MOTOR_RIGHT_IN1, LOW);
    digitalWrite(MOTOR_RIGHT_IN2, LOW);

    // Configurar PWM diretamente nas entradas do L298N
    ledcAttach(MOTOR_LEFT_IN1,
               MOTOR_PWM_FREQUENCY,
               MOTOR_PWM_RESOLUTION);

    ledcAttach(MOTOR_LEFT_IN2,
               MOTOR_PWM_FREQUENCY,
               MOTOR_PWM_RESOLUTION);

    ledcAttach(MOTOR_RIGHT_IN1,
               MOTOR_PWM_FREQUENCY,
               MOTOR_PWM_RESOLUTION);

    ledcAttach(MOTOR_RIGHT_IN2,
               MOTOR_PWM_FREQUENCY,
               MOTOR_PWM_RESOLUTION);

    // Inicializar todos os PWM em zero
    motor_stop();
}

// ======================================================
// Motor esquerdo
// ======================================================

void motor_set_left(int pwm)
{
    pwm = constrain(pwm, -MOTOR_PWM_MAX, MOTOR_PWM_MAX);

    // Desativar ambas as entradas antes de mudar o sentido
    ledcWrite(MOTOR_LEFT_IN1, 0);
    ledcWrite(MOTOR_LEFT_IN2, 0);

    if (pwm > 0)
    {
        // Frente
        ledcWrite(MOTOR_LEFT_IN1, pwm);
    }
    else if (pwm < 0)
    {
        // Ré
        ledcWrite(MOTOR_LEFT_IN2, -pwm);
    }
    // pwm == 0: ambas permanecem em LOW
}


// ======================================================
// Motor direito
// ======================================================

void motor_set_right(int pwm)
{
    pwm = constrain(pwm, -MOTOR_PWM_MAX, MOTOR_PWM_MAX);

    // Desativar ambas as entradas antes de mudar o sentido
    ledcWrite(MOTOR_RIGHT_IN1, 0);
    ledcWrite(MOTOR_RIGHT_IN2, 0);

    if (pwm > 0)
    {
        // Frente
        ledcWrite(MOTOR_RIGHT_IN1, pwm);
    }
    else if (pwm < 0)
    {
        // Ré
        ledcWrite(MOTOR_RIGHT_IN2, -pwm);
    }
    // pwm == 0: ambas permanecem em LOW
}


// ======================================================
// Controle dos dois motores
// ======================================================

void motor_set(int left_pwm, int right_pwm)
{
    motor_set_left(left_pwm);
    motor_set_right(right_pwm);
}


// ======================================================
// Parar os dois motores
// ======================================================

void motor_stop()
{
    motor_set_left(0);
    motor_set_right(0);
}
