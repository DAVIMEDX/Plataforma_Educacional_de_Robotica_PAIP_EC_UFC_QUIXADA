#include <Arduino.h>
#include "motor_control.h"

// ======================================================
// Inicialização dos motores
// ======================================================

void motor_init()
{
    pinMode(MOTOR_LEFT_IN1, OUTPUT);
    pinMode(MOTOR_LEFT_IN2, OUTPUT);

    pinMode(MOTOR_RIGHT_IN1, OUTPUT);
    pinMode(MOTOR_RIGHT_IN2, OUTPUT);

    bool left_ok = ledcAttach(
        MOTOR_LEFT_EN,
        MOTOR_PWM_FREQUENCY,
        MOTOR_PWM_RESOLUTION
    );

    bool right_ok = ledcAttach(
        MOTOR_RIGHT_EN,
        MOTOR_PWM_FREQUENCY,
        MOTOR_PWM_RESOLUTION
    );

    Serial.printf(
        "PWM esquerdo: %s | PWM direito: %s\n",
        left_ok ? "OK" : "ERRO",
        right_ok ? "OK" : "ERRO"
    );

    motor_stop();
}

// ======================================================
// Motor esquerdo
// ======================================================

void motor_set_left(int pwm)
{
    pwm = constrain(pwm, -MOTOR_PWM_MAX, MOTOR_PWM_MAX);

    if (pwm > 0)
    {
        digitalWrite(MOTOR_LEFT_IN1, HIGH);
        digitalWrite(MOTOR_LEFT_IN2, LOW);
        ledcWrite(MOTOR_LEFT_EN, pwm);
    }
    else if (pwm < 0)
    {
        digitalWrite(MOTOR_LEFT_IN1, LOW);
        digitalWrite(MOTOR_LEFT_IN2, HIGH);
        ledcWrite(MOTOR_LEFT_EN, -pwm);
    }
    else
    {
        digitalWrite(MOTOR_LEFT_IN1, LOW);
        digitalWrite(MOTOR_LEFT_IN2, LOW);
        ledcWrite(MOTOR_LEFT_EN, 0);
    }
}

// ======================================================
// Motor direito
// ======================================================

void motor_set_right(int pwm)
{
    pwm = constrain(pwm, -MOTOR_PWM_MAX, MOTOR_PWM_MAX);

    if (pwm > 0)
    {
        digitalWrite(MOTOR_RIGHT_IN1, HIGH);
        digitalWrite(MOTOR_RIGHT_IN2, LOW);
        ledcWrite(MOTOR_RIGHT_EN, pwm);
    }
    else if (pwm < 0)
    {
        digitalWrite(MOTOR_RIGHT_IN1, LOW);
        digitalWrite(MOTOR_RIGHT_IN2, HIGH);
        ledcWrite(MOTOR_RIGHT_EN, -pwm);
    }
    else
    {
        digitalWrite(MOTOR_RIGHT_IN1, LOW);
        digitalWrite(MOTOR_RIGHT_IN2, LOW);
        ledcWrite(MOTOR_RIGHT_EN, 0);
    }
}

// ======================================================
// Controle dos dois motores
// ======================================================

void motor_set(int left_pwm, int right_pwm)
{
    motor_set_left(left_pwm);
    motor_set_right(right_pwm);
}

// ======================================================
// Parada dos motores
// ======================================================

void motor_stop()
{
    motor_set_left(0);
    motor_set_right(0);
}
