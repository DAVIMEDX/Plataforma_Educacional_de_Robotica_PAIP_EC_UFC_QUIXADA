                 
 // ============================================================================
// ⚠️ ATENÇÃO: COMPATIBILIDADE DOS ENCODERS
// ============================================================================
// Este código foi desenvolvido considerando motores JGA 370 com encoders
// embutidos.
//
// Se você estiver utilizando motores ou encoders diferentes, pesquise e
// verifique como funciona a contagem de pulsos do modelo utilizado.
// A resolução do encoder e o método de contagem podem variar conforme o
// equipamento e exigem ajustes no código de leitura e na odometria.
//
// Não altere os parâmetros sem antes compreender as especificações do encoder.
// ============================================================================

#include <Arduino.h>
#include "encoder.h"


// Contadores dos encoders
volatile long left_pulses = 0;
volatile long right_pulses = 0;

// Estados anteriores dos canais
volatile uint8_t left_previous_state = 0;
volatile uint8_t right_previous_state = 0;

// Tabela de transições em quadratura.
// O sinal indica o sentido da contagem.
const int8_t quadrature_table[16] = {
     0, -1,  1,  0,
     1,  0,  0, -1,
    -1,  0,  0,  1,
     0,  1, -1,  0
};

void IRAM_ATTR left_encoder_isr()
{
    uint8_t a = digitalRead(ENCODER_LEFT_PIN_A);
    uint8_t b = digitalRead(ENCODER_LEFT_PIN_B);

    uint8_t current_state = (a << 1) | b;

    uint8_t index =
        (left_previous_state << 2) | current_state;

    left_pulses += quadrature_table[index];
    left_previous_state = current_state;
}

void IRAM_ATTR right_encoder_isr()
{
    uint8_t a = digitalRead(ENCODER_RIGHT_PIN_A);
    uint8_t b = digitalRead(ENCODER_RIGHT_PIN_B);

    uint8_t current_state = (a << 1) | b;

    uint8_t index =
        (right_previous_state << 2) | current_state;

    right_pulses += quadrature_table[index];
    right_previous_state = current_state;
}

void encoder_init()
{
    // Os GPIOs 34 e 35 não possuem pull-up interno.
    pinMode(ENCODER_LEFT_PIN_A, INPUT);
    pinMode(ENCODER_LEFT_PIN_B, INPUT);
    pinMode(ENCODER_RIGHT_PIN_A, INPUT);
    pinMode(ENCODER_RIGHT_PIN_B, INPUT);

    // Registrar os estados iniciais antes das interrupções.
    left_previous_state =
        (digitalRead(ENCODER_LEFT_PIN_A) << 1) |
         digitalRead(ENCODER_LEFT_PIN_B);

    right_previous_state =
        (digitalRead(ENCODER_RIGHT_PIN_A) << 1) |
         digitalRead(ENCODER_RIGHT_PIN_B);

    attachInterrupt(
        digitalPinToInterrupt(ENCODER_LEFT_PIN_A),
        left_encoder_isr,
        CHANGE
    );

    attachInterrupt(
        digitalPinToInterrupt(ENCODER_LEFT_PIN_B),
        left_encoder_isr,
        CHANGE
    );

    attachInterrupt(
        digitalPinToInterrupt(ENCODER_RIGHT_PIN_A),
        right_encoder_isr,
        CHANGE
    );

    attachInterrupt(
        digitalPinToInterrupt(ENCODER_RIGHT_PIN_B),
        right_encoder_isr,
        CHANGE
    );
}

long encoder_get_left()
{
    noInterrupts();
    long value = left_pulses;
    interrupts();

    return value;
}

long encoder_get_right()
{
    noInterrupts();
    long value = right_pulses;
    interrupts();

    return value;
}

void encoder_reset()
{
    noInterrupts();

    left_pulses = 0;
    right_pulses = 0;

    interrupts();
}
