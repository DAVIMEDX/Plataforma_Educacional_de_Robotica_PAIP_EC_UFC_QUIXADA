#include "motor_control.h"
#include "encoder.h"
#include "odometry.h"
#include "micro_ros.h"


void setup()
{
    motor_init();

    encoder_init();

    odometry_init();

    micro_ros_init();
}


void loop()
{
    micro_ros_spin();
}