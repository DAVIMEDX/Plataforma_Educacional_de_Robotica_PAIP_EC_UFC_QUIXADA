#include <Arduino.h>

#include "motor_control.h"
#include "encoder.h"
#include "odometry.h"
#include "micro_ros.h"

void setup()
{
    Serial.begin(115200);
    delay(1000);

    // Inicializa os motores
    motor_init();

    // Inicializa os encoders
    encoder_init();

    // Inicializa a odometria após os encoders
    odometry_init();

    // Inicializa Wi-Fi e Micro-ROS
    micro_ros_init();
}

void loop()
{
    // Processa /cmd_vel, watchdog e /odom
    micro_ros_spin();

    delay(10);
}