#ifndef MOTOR_CONTROL_H
#define MOTOR_CONTROL_H

// ================================
// Pinos do L298N
// ================================

// Motor esquerdo
#define MOTOR_LEFT_EN   25
#define MOTOR_LEFT_IN1  26
#define MOTOR_LEFT_IN2  27

// Motor direito
#define MOTOR_RIGHT_EN  14
#define MOTOR_RIGHT_IN1 32
#define MOTOR_RIGHT_IN2 33

// ================================
// Configuração PWM
// ================================

#define MOTOR_PWM_FREQUENCY 20000
#define MOTOR_PWM_RESOLUTION 8
#define MOTOR_PWM_MAX 255

// ================================
// Funções
// ================================

void motor_init();

void motor_set_left(int pwm);
void motor_set_right(int pwm);

void motor_set(int left_pwm, int right_pwm);

void motor_stop();

#endif